#!/bin/bash
# garrison.sh — start, stop, status, logs for all Garrison components
# Usage: ./garrison.sh [start|stop|restart|status|logs]

set -e

COMPOSE_FILE="$(dirname "$0")/docker-compose.yml"
SERVICES=("garrison-qdrant" "garrison-webui" "garrison-agent" "ollama")

cmd="${1:-status}"

case "$cmd" in
  start)
    echo "[garrison] Starting containers..."
    docker compose -f "$COMPOSE_FILE" up -d
    echo "[garrison] Starting systemd services..."
    sudo systemctl start ollama
    sudo systemctl start garrison-agent
    echo "[garrison] All services started."
    ;;

  stop)
    echo "[garrison] Stopping containers..."
    docker compose -f "$COMPOSE_FILE" down
    echo "[garrison] Stopping systemd services..."
    sudo systemctl stop garrison-agent
    echo "[garrison] Stopped. (Ollama left running — stop manually if needed)"
    ;;

  restart)
    "$0" stop
    sleep 2
    "$0" start
    ;;

  status)
    echo "=== Garrison Status ==="
    echo ""
    echo "-- Docker containers --"
    docker compose -f "$COMPOSE_FILE" ps
    echo ""
    echo "-- Ollama --"
    systemctl is-active ollama && echo "ollama: running" || echo "ollama: stopped"
    echo ""
    echo "-- Gary (collector) --"
    systemctl is-active garrison-agent && echo "garrison-agent: running" || echo "garrison-agent: stopped"
    echo ""
    echo "-- Open WebUI --"
    echo "  http://localhost:3000"
    echo ""
    echo "-- Qdrant --"
    echo "  http://localhost:6333/dashboard"
    ;;

  logs)
    service="${2:-garrison-agent}"
    case "$service" in
      qdrant|webui)
        docker compose -f "$COMPOSE_FILE" logs -f "$service"
        ;;
      gary|agent|garrison-agent)
        journalctl -u garrison-agent -f
        ;;
      ollama)
        journalctl -u ollama -f
        ;;
      *)
        echo "Usage: $0 logs [qdrant|webui|gary|ollama]"
        ;;
    esac
    ;;

  gary)
    # Launch Gary interactively
    cd "$(dirname "$0")"
    source venv/bin/activate
    python agent.py "${@:2}"
    ;;

  *)
    echo "Usage: $0 [start|stop|restart|status|logs|gary]"
    echo ""
    echo "  start          Start all Garrison services"
    echo "  stop           Stop all Garrison services"
    echo "  restart        Restart all services"
    echo "  status         Show status of all components"
    echo "  logs [svc]     Tail logs (qdrant, webui, gary, ollama)"
    echo "  gary [query]   Talk to Gary directly in the terminal"
    ;;
esac
